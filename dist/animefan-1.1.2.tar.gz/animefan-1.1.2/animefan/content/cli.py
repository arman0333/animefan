def main():
    print("Welcome to the Anime CLI!")

if __name__ == "__main__":
    main()
