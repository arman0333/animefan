from .main import hello

if __name__ == "__main__":
    hello()
